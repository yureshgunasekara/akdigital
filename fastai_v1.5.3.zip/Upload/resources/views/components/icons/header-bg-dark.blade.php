<svg 
    viewBox="0 0 1190 806" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
    class="hidden dark:block absolute -top-[200px] left-0 right-0 mx-auto"
>
    <g filter="url(#filter0_f_838_10637)">
    <ellipse cx="795" cy="348" rx="100" ry="158" fill="#CB7AF1"/>
    </g>
    <g filter="url(#filter1_f_838_10637)">
    <ellipse cx="452.5" cy="208" rx="192.5" ry="58" fill="#907AF1"/>
    </g>
    <defs>
    <filter id="filter0_f_838_10637" x="395" y="-110" width="800" height="916" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
    <feGaussianBlur stdDeviation="150" result="effect1_foregroundBlur_838_10637"/>
    </filter>
    <filter id="filter1_f_838_10637" x="0" y="-110" width="905" height="636" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
    <feGaussianBlur stdDeviation="130" result="effect1_foregroundBlur_838_10637"/>
    </filter>
    </defs>
</svg>
