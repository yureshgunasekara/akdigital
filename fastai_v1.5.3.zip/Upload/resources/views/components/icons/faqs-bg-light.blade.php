<svg 
    viewBox="0 0 931 914" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg" 
    class="block dark:hidden absolute -top-[120px] right-0 -z-10" 
>
    <g filter="url(#filter0_f_667_9447)">
    <ellipse cx="330.472" cy="410.264" rx="100.573" ry="83.4001" fill="#C8BAFC"/>
    </g>
    <g filter="url(#filter1_f_667_9447)">
    <ellipse cx="662.426" cy="313.049" rx="100.573" ry="83.4001" fill="#9DF7C2"/>
    </g>
    <g filter="url(#filter2_f_667_9447)">
    <ellipse cx="587.151" cy="600.6" rx="100.573" ry="83.4001" fill="#FFEBB3"/>
    </g>
    <defs>
    <filter id="filter0_f_667_9447" x="0.589142" y="97.5542" width="659.766" height="625.419" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
    <feGaussianBlur stdDeviation="114.655" result="effect1_foregroundBlur_667_9447"/>
    </filter>
    <filter id="filter1_f_667_9447" x="332.543" y="0.339386" width="659.766" height="625.419" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
    <feGaussianBlur stdDeviation="114.655" result="effect1_foregroundBlur_667_9447"/>
    </filter>
    <filter id="filter2_f_667_9447" x="257.268" y="287.89" width="659.766" height="625.419" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
    <feGaussianBlur stdDeviation="114.655" result="effect1_foregroundBlur_667_9447"/>
    </filter>
    </defs>
</svg>
    