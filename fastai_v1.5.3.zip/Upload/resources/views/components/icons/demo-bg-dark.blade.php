

<svg 
    viewBox="0 0 1389 693" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg" 
    class="hidden dark:block absolute left-0 right-0 mx-auto {{$class}}"
>
    <g filter="url(#filter0_f_677_10438)">
    <ellipse cx="903" cy="346" rx="216" ry="56" fill="#CB7AF1"/>
    </g>
    <g filter="url(#filter1_f_677_10438)">
    <ellipse cx="449.5" cy="391" rx="199.5" ry="52" fill="#997AF1"/>
    </g>
    <defs>
    <filter id="filter0_f_677_10438" x="397" y="0" width="1012" height="692" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
    <feGaussianBlur stdDeviation="145" result="effect1_foregroundBlur_677_10438"/>
    </filter>
    <filter id="filter1_f_677_10438" x="0" y="89" width="899" height="604" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
    <feGaussianBlur stdDeviation="125" result="effect1_foregroundBlur_677_10438"/>
    </filter>
    </defs>
</svg>