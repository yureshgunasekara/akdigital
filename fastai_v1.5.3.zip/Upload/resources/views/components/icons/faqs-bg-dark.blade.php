<svg 
    viewBox="0 0 1440 954" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg" 
    class="hidden dark:block absolute -top-[180px] left-0 right-0 mx-auto" 
>
    <g filter="url(#filter0_f_677_10598)">
    <ellipse cx="502.5" cy="477" rx="164.5" ry="117" fill="#997AF1"/>
    </g>
    <g filter="url(#filter1_f_677_10598)">
    <ellipse cx="857" cy="436" rx="92" ry="76" fill="#C8BAFC"/>
    </g>
    <g filter="url(#filter2_f_677_10598)">
    <ellipse cx="1106.5" cy="375" rx="105.5" ry="119" fill="#9DF7C2"/>
    </g>
    <g filter="url(#filter3_f_677_10598)">
    <ellipse cx="1091" cy="629.5" rx="92" ry="76.5" fill="#FFEBB3"/>
    </g>
    <defs>
    <filter id="filter0_f_677_10598" x="-22" y="0" width="1049" height="954" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
    <feGaussianBlur stdDeviation="180" result="effect1_foregroundBlur_677_10598"/>
    </filter>
    <filter id="filter1_f_677_10598" x="533.11" y="128.11" width="647.781" height="615.781" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
    <feGaussianBlur stdDeviation="115.945" result="effect1_foregroundBlur_677_10598"/>
    </filter>
    <filter id="filter2_f_677_10598" x="769.11" y="24.1096" width="674.781" height="701.781" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
    <feGaussianBlur stdDeviation="115.945" result="effect1_foregroundBlur_677_10598"/>
    </filter>
    <filter id="filter3_f_677_10598" x="767.11" y="321.11" width="647.781" height="616.781" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
    <feFlood flood-opacity="0" result="BackgroundImageFix"/>
    <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape"/>
    <feGaussianBlur stdDeviation="115.945" result="effect1_foregroundBlur_677_10598"/>
    </filter>
    </defs>
</svg>
            