
<style>
    .bg-color-shadow::before {
      content: "";
      position: absolute;
      left: 56%;
      bottom: 0%;
      z-index: 1;
      width: 565px;
      height: 147px;
      /* opacity: 5.13; */
      filter: blur(175px);
      /* transform: translate(-40%, -50%) rotate(8deg); */
      background-color: rgba(203, 122, 241, 1);
      border-radius: 100%;
      pointer-events: none;
   }
</style>
<div class="bg-color-shadow"></div>